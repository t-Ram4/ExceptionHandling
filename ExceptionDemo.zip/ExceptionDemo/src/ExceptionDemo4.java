
public class ExceptionDemo4 {

	public static void main(String[] args) throws IllegalAccessException{
		
		//try{
			
			ThrowDemo.throwOne();
			
		//}
		//catch(IllegalAccessException e){
			//System.out.println("Caught inside catch block "+e);
			
		//}
	}

}

class ThrowDemo{
	
	static void throwOne() throws IllegalAccessException {
		
		System.out.println("inside throwOne method");
		
		throw new IllegalAccessException();
	}
	
	
}