
public class ExceptionDemo3 {

	public static void main(String[] args) {
		
		
		try{
			
			System.out.println("inside try block ");
			
			if(true){
				throw new NullPointerException("Demo");
			}
			
			System.out.println("This will not be printed");
			
		}
		catch(NullPointerException e){
			System.out.println("inside catch block "+e);
			
		}

	}

}
