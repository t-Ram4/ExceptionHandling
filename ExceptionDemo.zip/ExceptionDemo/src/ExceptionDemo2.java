
public class ExceptionDemo2 {

	public static void main(String[] args) {
		
		int a[]={1,2,3};
		
		int b = a.length;
		
		try{
			
			System.out.println("No exception is thrown");
			
		}catch(Exception e){
			
			System.out.println("it will not be printed");
		}
		finally{
			
			System.out.println("inside finally1");
		}
		
		try{
			int c = 0;
			int d =b/c;
			
		}
		catch(ArithmeticException e){
			
			System.out.println("divide by zero");
		}
		finally{
			
			System.out.println("inside finally2");
		}
		
		try{
			
			int k =a[b+1];
			
		}catch(ArithmeticException e){
			
			System.out.println("it will not be printed");
		}
		finally{
			
			System.out.println("inside finally3");
		}
		
		

	}

}
