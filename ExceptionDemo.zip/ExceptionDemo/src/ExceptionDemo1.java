
public class ExceptionDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int d,a;
		
		//try{
			
			d=0;
			a = 40/d;
			
			System.out.println("This will not be printed");
			
		//}
		//catch(ArithmeticException e){
			///System.out.println("Division by zero");
			
		//}
		System.out.println("After the catch block");
	}

}
